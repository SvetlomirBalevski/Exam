﻿/// <summary>
/// Reads input from console and pass commands
/// </summary>
namespace ProjectManager.Common.Contracts
{
   public interface IEngine
    {
        void Start();
    }
}
